
Name       : Sushruth Radhakrishna          
JDK Used   : jdk 1.8                        
IDE Used   : IntelliJ                       
IDE Version: Community 2017.3            

Main File: Main.java                 
Load File: InputReader.java, Change file path in the constructor InputReader.java and then run Main.java 

Other Instructions: 1) Package Name --> com.company;                                  

		    2) Classes --> Main.java, Board.java, InputReader.java, CheckersData.java, CheckersMove.java
											  									
		    3) UI Contents --> Checkers Board, 4 Buttons and 1 Label.

		    4) Next --> Simulates the move from the input files. This button is available when the game is launched.
                    
                    5) Previous --> Comes to the previous state.

		    6) Button Quit  --> Ends the current game. This button is available when the game is launched.

		    7) Button New Game --> Allows user to play a game from start. This button is not available when the game launches because there is already a new game available at that instance. Once             you click Quit, this button will become available.
									
		    8) Pop-ups --> There will be pop-up message box for every invalid move. You can close the pop-up by clicking on ok or close symbol.
